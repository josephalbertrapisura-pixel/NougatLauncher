package com.launcher.nougat

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.SpannableString
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.GestureDetector
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class LauncherActivity : AppCompatActivity() {

    companion object {
        const val HOME_COLUMNS = 5
        const val HOME_ROWS = 2   // the reference shows 2 rows; raise for more icons
    }

    // Packages to pin on the home screen, in order. Leave empty to use the
    // first apps A-Z. Example: "com.instagram.android", "com.spotify.music"
    private val homePackages = listOf<String>()

    private lateinit var drawer: View
    private lateinit var dock: LinearLayout
    private lateinit var homeGrid: GridLayout
    private lateinit var pageDots: LinearLayout
    private lateinit var searchBox: EditText
    private lateinit var adapter: AppAdapter
    private var allApps = listOf<AppInfo>()
    private var drawerOpen = false

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadApps()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_launcher)

        drawer = findViewById(R.id.drawer)
        dock = findViewById(R.id.dock)
        homeGrid = findViewById(R.id.homeGrid)
        pageDots = findViewById(R.id.pageDots)
        searchBox = findViewById(R.id.search)

        homeGrid.columnCount = HOME_COLUMNS
        homeGrid.rowCount = HOME_ROWS

        setGoogleLogo(findViewById(R.id.searchLogo))
        findViewById<View>(R.id.searchBar).setOnClickListener {
            try {
                startActivity(Intent(Intent.ACTION_WEB_SEARCH))
            } catch (_: Exception) {}
        }

        val list = findViewById<RecyclerView>(R.id.appList)
        list.layoutManager = GridLayoutManager(this, 5)
        adapter = AppAdapter { launch(it.packageName) }
        list.adapter = adapter

        searchBox.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString().orEmpty().trim()
                adapter.submit(allApps.filter { it.label.contains(q, ignoreCase = true) })
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })

        // Swipe up on the home screen to open the drawer
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(
                e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float
            ): Boolean {
                if (vy < -1000f) { openDrawer(); return true }
                return false
            }
        })
        findViewById<View>(R.id.home).setOnTouchListener { _, e ->
            detector.onTouchEvent(e)
            true
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (drawerOpen) closeDrawer()
            }
        })

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        }
        registerReceiver(pkgReceiver, filter)

        loadApps()
        buildPageDots()
        buildDock()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (drawerOpen) closeDrawer() // Home button closes the drawer
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(pkgReceiver)
    }

    private fun loadApps() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        allApps = packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                AppInfo(
                    it.loadLabel(packageManager).toString(),
                    it.loadIcon(packageManager),
                    it.activityInfo.packageName
                )
            }
            .sortedBy { it.label.lowercase() }
        adapter.submit(allApps)
        buildHomeGrid()
    }

    private fun launch(pkg: String) {
        packageManager.getLaunchIntentForPackage(pkg)?.let {
            startActivity(it)
            closeDrawer()
        }
    }

    // Colored "Google" wordmark like the Nougat search bar
    private fun setGoogleLogo(tv: TextView) {
        val colors = intArrayOf(
            0xFF4285F4.toInt(), 0xFFEA4335.toInt(), 0xFFFBBC05.toInt(),
            0xFF4285F4.toInt(), 0xFF34A853.toInt(), 0xFFEA4335.toInt()
        )
        val s = SpannableString("Google")
        colors.forEachIndexed { i, c ->
            s.setSpan(ForegroundColorSpan(c), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        tv.text = s
    }

    // Home screen icon grid: 5 columns, labels in white
    private fun buildHomeGrid() {
        homeGrid.removeAllViews()
        val pinned = homePackages.mapNotNull { p -> allApps.firstOrNull { it.packageName == p } }
        val picks = (pinned + allApps.filter { it !in pinned })
            .take(HOME_COLUMNS * HOME_ROWS)

        picks.forEachIndexed { i, app ->
            val cell = LayoutInflater.from(this).inflate(R.layout.item_home_icon, homeGrid, false)
            cell.findViewById<ImageView>(R.id.icon).setImageDrawable(app.icon)
            cell.findViewById<TextView>(R.id.label).text = app.label
            cell.setOnClickListener { launch(app.packageName) }

            val lp = GridLayout.LayoutParams(
                GridLayout.spec(i / HOME_COLUMNS),
                GridLayout.spec(i % HOME_COLUMNS, 1f)
            )
            lp.width = 0
            homeGrid.addView(cell, lp)
        }
    }

    // Three page dots, first one active
    private fun buildPageDots() {
        pageDots.removeAllViews()
        repeat(3) { i ->
            val dot = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.WHITE)
                }
                alpha = if (i == 0) 1f else 0.5f
                layoutParams = LinearLayout.LayoutParams(dp(6), dp(6)).apply {
                    marginStart = dp(4)
                    marginEnd = dp(4)
                }
            }
            pageDots.addView(dot)
        }
    }

    // Dock: 2 favorites | round drawer button | 2 favorites
    private fun buildDock() {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        val items = intents.mapNotNull { i ->
            packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
                ?.let { Pair(it.loadIcon(packageManager), i) }
        }
        val left = items.take(2)
        val right = items.drop(2)

        dock.removeAllViews()
        repeat(2 - left.size) { dock.addView(spacer()) }
        left.forEach { dock.addView(dockIcon(it.first, it.second)) }

        dock.addView(drawerButton())

        right.forEach { dock.addView(dockIcon(it.first, it.second)) }
        repeat(2 - right.size) { dock.addView(spacer()) }
    }

    private fun spacer(): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
    }

    private fun drawerButton(): View {
        return ImageView(this).apply {
            setImageResource(R.drawable.ic_drawer_button)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            layoutParams = LinearLayout.LayoutParams(0, dp(60), 1f)
            setOnClickListener { openDrawer() }
        }
    }

    private fun dockIcon(icon: Drawable, intent: Intent): View {
        val size = dp(60)
        return ImageView(this).apply {
            setImageDrawable(icon)
            setPadding(size / 7, size / 7, size / 7, size / 7)
            layoutParams = LinearLayout.LayoutParams(0, size, 1f)
            setOnClickListener {
                try { startActivity(intent) } catch (_: Exception) {}
            }
        }
    }

    private fun openDrawer() {
        if (drawerOpen) return
        drawerOpen = true
        // Dark status bar icons on the white drawer
        WindowCompat.getInsetsController(window, window.decorView)
            .isAppearanceLightStatusBars = true
        drawer.visibility = View.VISIBLE
        drawer.translationY = drawer.height.toFloat()
        drawer.alpha = 0f
        drawer.animate().translationY(0f).alpha(1f).setDuration(250).start()
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        WindowCompat.getInsetsController(window, window.decorView)
            .isAppearanceLightStatusBars = false
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(searchBox.windowToken, 0)
        searchBox.setText("")
        drawer.animate()
            .translationY(drawer.height.toFloat()).alpha(0f).setDuration(200)
            .withEndAction { drawer.visibility = View.INVISIBLE }
            .start()
    }
}
